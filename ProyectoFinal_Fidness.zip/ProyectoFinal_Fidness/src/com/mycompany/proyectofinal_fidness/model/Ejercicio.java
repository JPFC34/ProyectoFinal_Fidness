package com.mycompany.proyectofinal_fidness.model;

public class Ejercicio {
    private int id;
    private String nombre;
    private String categoria; // Pierna, Espalda, Brazo, etc.
    private String descripcion;
    private String videoUrl; // URL o ruta al video demostrativo
    
    public Ejercicio() {}
    
    public Ejercicio(String nombre, String categoria, String descripcion, String videoUrl) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.videoUrl = videoUrl;
    }
    
    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getVideoUrl() { return videoUrl; }
    public void setVideoUrl(String videoUrl) { this.videoUrl = videoUrl; }
}