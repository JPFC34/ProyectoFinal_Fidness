package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.dao.EjercicioDAO;
import com.mycompany.proyectofinal_fidness.model.Ejercicio;
import com.mycompany.proyectofinal_fidness.model.Usuario;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class EjercicioFrame extends JFrame {
    private Usuario usuario;
    private EjercicioDAO ejercicioDAO;
    private JComboBox<String> comboCategorias;
    private JList<Ejercicio> listaEjercicios;
    private DefaultListModel<Ejercicio> modeloEjercicios;
    private JTextArea txtDescripcion;

    public EjercicioFrame(Usuario usuario) {
        this.usuario = usuario;
        this.ejercicioDAO = new EjercicioDAO();
        
        setTitle("Fidness - Catálogo de Ejercicios");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
        cargarEjercicios("Todos");
    }
    
    private void initComponents() {
        JPanel panelSuperior = new JPanel(new FlowLayout());
        comboCategorias = new JComboBox<>(new String[]{"Todos", "Pierna", "Espalda", "Brazo", "Abdomen", "Cardio"});
        comboCategorias.addActionListener(e -> {
            String categoria = (String) comboCategorias.getSelectedItem();
            cargarEjercicios(categoria.equals("Todos") ? null : categoria);
        });
        panelSuperior.add(new JLabel("FILTRAR POR CATEGORÍA:"));
        panelSuperior.add(comboCategorias);
        
        modeloEjercicios = new DefaultListModel<>();
        listaEjercicios = new JList<>(modeloEjercicios);
        listaEjercicios.setCellRenderer(new EjercicioListCellRenderer());
        listaEjercicios.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    Ejercicio seleccionado = listaEjercicios.getSelectedValue();
                    if (seleccionado != null) {
                        mostrarDetalleEjercicio(seleccionado);
                    }
                }
            }
        });
        
        JScrollPane scrollLista = new JScrollPane(listaEjercicios);
        
        // Panel para detalles del ejercicio
        JPanel panelDetalle = new JPanel(new BorderLayout());
        panelDetalle.setBorder(new TitledBorder("DETALLES DEL EJERCICIO"));
        
        txtDescripcion = new JTextArea(15, 30);
        txtDescripcion.setEditable(false);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane scrollDescripcion = new JScrollPane(txtDescripcion);
        
        panelDetalle.add(scrollDescripcion, BorderLayout.CENTER);
        
        add(panelSuperior, BorderLayout.NORTH);
        add(scrollLista, BorderLayout.WEST);
        add(panelDetalle, BorderLayout.CENTER);
    }
    
    private void cargarEjercicios(String categoria) {
        modeloEjercicios.clear();
        
        List<Ejercicio> ejercicios;
        if (categoria == null) {
            ejercicios = ejercicioDAO.obtenerTodos();
        } else {
            ejercicios = ejercicioDAO.obtenerPorCategoria(categoria);
        }
        
        for (Ejercicio ejercicio : ejercicios) {
            modeloEjercicios.addElement(ejercicio);
        }
        
        // Mostrar mensaje si no hay ejercicios
        if (ejercicios.isEmpty()) {
            txtDescripcion.setText("No hay ejercicios disponibles para la categoría seleccionada.\n\n" +
                                "Por favor, seleccione otra categoría o contacte al administrador para agregar más ejercicios.");
        } else {
            txtDescripcion.setText("Seleccione un ejercicio de la lista para ver sus detalles.");
        }
    }
    
    private void mostrarDetalleEjercicio(Ejercicio ejercicio) {
        StringBuilder detalle = new StringBuilder();
        detalle.append("NOMBRE DEL EJERCICIO: ").append(ejercicio.getNombre()).append("\n\n");
        detalle.append("CATEGORÍA: ").append(ejercicio.getCategoria()).append("\n\n");
        detalle.append("DESCRIPCIÓN:\n").append(ejercicio.getDescripcion()).append("\n\n");
        detalle.append("VIDEO DEMOSTRATIVO:\n").append(ejercicio.getVideoUrl());
        
        txtDescripcion.setText(detalle.toString());
        txtDescripcion.setCaretPosition(0); // Posicionar al inicio del texto
    }
}