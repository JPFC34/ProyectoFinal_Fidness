package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.model.Rutina;
import java.awt.Color;
import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class RutinaListCellRenderer extends DefaultListCellRenderer {
    private Border border = new LineBorder(Color.LIGHT_GRAY, 1);
    
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
            boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
        if (value instanceof Rutina) {
            Rutina rutina = (Rutina) value;
            int numEjercicios = rutina.getEjercicios() != null ? rutina.getEjercicios().size() : 0;
            
            // Formato del texto con información detallada
            String texto = "<html><b>" + rutina.getNombre() + "</b><br>" +
                          "<font size=2 color=gray>" + numEjercicios + " ejercicio(s) en esta rutina</font><br>" +
                          "<font size=2>Última actualización: Hoy</font></html>";
            setText(texto);
            
            // Borde y espaciado
            setBorder(border);
            setOpaque(true);
            
            // Color de fondo
            setBackground(new Color(240, 248, 255));
        }
        
        return this;
    }
}