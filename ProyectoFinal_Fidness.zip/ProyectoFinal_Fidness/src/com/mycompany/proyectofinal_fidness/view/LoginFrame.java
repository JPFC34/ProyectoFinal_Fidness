package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.dao.UsuarioDAO;
import com.mycompany.proyectofinal_fidness.model.Usuario;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFrame extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private UsuarioDAO usuarioDAO;

    public LoginFrame() {
        usuarioDAO = new UsuarioDAO();
        
        setTitle("Fidness - Inicio de Sesión");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }
    
    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        
        panel.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        panel.add(txtUsuario);
        
        panel.add(new JLabel("Contraseña:"));
        txtPassword = new JPasswordField();
        panel.add(txtPassword);
        
        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.addActionListener(e -> login());
        panel.add(btnLogin);
        
        add(panel, BorderLayout.CENTER);
    }
    
    private void login() {
        String username = txtUsuario.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar usuario y contraseña", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Usuario usuario = usuarioDAO.validarCredenciales(username, password);
        
        if (usuario != null) {
            JOptionPane.showMessageDialog(this, "Bienvenido " + usuario.getUsername(), "Login Exitoso", JOptionPane.INFORMATION_MESSAGE);
            
            MainFrame mainFrame = new MainFrame(usuario);
            mainFrame.setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales inválidas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}