package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.model.Ejercicio;
import java.awt.Color;
import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class EjercicioListCellRenderer extends DefaultListCellRenderer {
    private Border border = new LineBorder(Color.LIGHT_GRAY, 1);
    
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
            boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
        if (value instanceof Ejercicio) {
            Ejercicio ejercicio = (Ejercicio) value;
            
            // Formato del texto con información detallada
            String texto = "<html><b>" + ejercicio.getNombre() + "</b><br>" +
                          "<font size=2 color=gray>Categoría: " + ejercicio.getCategoria() + "</font><br>" +
                          "<font size=2>" + (ejercicio.getDescripcion().length() > 50 ? 
                          ejercicio.getDescripcion().substring(0, 50) + "..." : 
                          ejercicio.getDescripcion()) + "</font></html>";
            setText(texto);
            
            // Borde y espaciado
            setBorder(border);
            setOpaque(true);
            
            // Color de fondo según categoría
            switch (ejercicio.getCategoria()) {
                case "Pierna":
                    setBackground(new Color(255, 230, 230));
                    break;
                case "Espalda":
                    setBackground(new Color(230, 255, 230));
                    break;
                case "Brazo":
                    setBackground(new Color(230, 230, 255));
                    break;
                case "Abdomen":
                    setBackground(new Color(255, 255, 230));
                    break;
                case "Cardio":
                    setBackground(new Color(255, 230, 255));
                    break;
                default:
                    setBackground(Color.WHITE);
            }
        }
        
        return this;
    }
}