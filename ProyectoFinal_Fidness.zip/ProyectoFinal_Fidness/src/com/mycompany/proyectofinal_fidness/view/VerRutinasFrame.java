package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.dao.RutinaDAO;
import com.mycompany.proyectofinal_fidness.model.Ejercicio;
import com.mycompany.proyectofinal_fidness.model.Rutina;
import com.mycompany.proyectofinal_fidness.model.Usuario;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class VerRutinasFrame extends JFrame {
    private Usuario usuario;
    private RutinaDAO rutinaDAO;
    private JList<Rutina> listaRutinas;
    private DefaultListModel<Rutina> modeloRutinas;
    private JTextArea txtDetalleRutina;
    private JButton btnEliminar;
    private JLabel lblInfo;

    public VerRutinasFrame(Usuario usuario) {
        this.usuario = usuario;
        this.rutinaDAO = new RutinaDAO();
        
        setTitle("Fidness - Mis Rutinas");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
        cargarRutinas();
    }
    
    private void initComponents() {
        // Panel izquierdo para lista de rutinas
        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.setBorder(new TitledBorder("MIS RUTINAS GUARDADAS"));
        
        modeloRutinas = new DefaultListModel<>();
        listaRutinas = new JList<>(modeloRutinas);
        listaRutinas.setCellRenderer(new RutinaListCellRenderer());
        listaRutinas.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    Rutina seleccionada = listaRutinas.getSelectedValue();
                    if (seleccionada != null) {
                        mostrarDetalleRutina(seleccionada);
                    }
                }
            }
        });
        
        panelIzquierdo.add(new JScrollPane(listaRutinas), BorderLayout.CENTER);
        
        // Panel derecho para detalles
        JPanel panelDerecho = new JPanel(new BorderLayout());
        panelDerecho.setBorder(new TitledBorder("DETALLE COMPLETO DE LA RUTINA"));
        
        txtDetalleRutina = new JTextArea(20, 30);
        txtDetalleRutina.setEditable(false);
        txtDetalleRutina.setLineWrap(true);
        txtDetalleRutina.setWrapStyleWord(true);
        JScrollPane scrollDetalle = new JScrollPane(txtDetalleRutina);
        
        panelDerecho.add(scrollDetalle, BorderLayout.CENTER);
        
        // Panel inferior para botones
        JPanel panelInferior = new JPanel(new FlowLayout());
        btnEliminar = new JButton("ELIMINAR RUTINA");
        btnEliminar.addActionListener(e -> eliminarRutina());
        panelInferior.add(btnEliminar);
        
        lblInfo = new JLabel("Seleccione una rutina para ver sus detalles");
        panelInferior.add(lblInfo);
        
        // Layout principal
        JPanel panelPrincipal = new JPanel(new GridLayout(1, 2, 10, 10));
        panelPrincipal.add(panelIzquierdo);
        panelPrincipal.add(panelDerecho);
        
        add(panelPrincipal, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);
    }
    
    private void cargarRutinas() {
        modeloRutinas.clear();
        List<Rutina> rutinas = rutinaDAO.obtenerPorUsuario(usuario.getId());
        
        for (Rutina rutina : rutinas) {
            modeloRutinas.addElement(rutina);
        }
        
        // Mostrar mensaje si no hay rutinas
        if (rutinas.isEmpty()) {
            txtDetalleRutina.setText("========================================\n" +
                                    "NO TIENE RUTINAS GUARDADAS\n" +
                                    "========================================\n\n" +
                                    "Para crear una nueva rutina:\n" +
                                    "1. Vaya al menú 'Rutinas'\n" +
                                    "2. Seleccione 'Crear Rutina'\n" +
                                    "3. Seleccione los ejercicios que desea incluir\n" +
                                    "4. Asigne un nombre a su rutina\n" +
                                    "5. Guarde su rutina personalizada\n\n" +
                                    "Sus rutinas aparecerán aquí para su consulta.");
            lblInfo.setText("No hay rutinas disponibles. Cree una nueva rutina desde el menú principal.");
        } else {
            lblInfo.setText("Tiene " + rutinas.size() + " rutina" + (rutinas.size() != 1 ? "s" : "") + " guardada" + (rutinas.size() != 1 ? "s" : ""));
        }
    }
    
    private void mostrarDetalleRutina(Rutina rutina) {
        StringBuilder detalle = new StringBuilder();
        detalle.append("========================================\n");
        detalle.append("RUTINA: ").append(rutina.getNombre()).append("\n");
        detalle.append("========================================\n\n");
        
        detalle.append("EJERCICIOS INCLUIDOS (").append(rutina.getEjercicios().size()).append("):\n");
        detalle.append("----------------------------------------\n");
        
        for (int i = 0; i < rutina.getEjercicios().size(); i++) {
            Ejercicio ejercicio = rutina.getEjercicios().get(i);
            detalle.append(i + 1).append(". ").append(ejercicio.getNombre()).append("\n");
            detalle.append("   Categoría: ").append(ejercicio.getCategoria()).append("\n");
            detalle.append("   Descripción: ").append(ejercicio.getDescripcion()).append("\n\n");
        }
        
        detalle.append("========================================\n");
        detalle.append("INSTRUCCIONES:\n");
        detalle.append("Realizar cada ejercicio con la técnica adecuada.\n");
        detalle.append("Descansar 30 segundos entre series.\n");
        detalle.append("Mantener una hidratación adecuada.\n");
        detalle.append("========================================\n");
        
        txtDetalleRutina.setText(detalle.toString());
        txtDetalleRutina.setCaretPosition(0); // Posicionar al inicio del texto
        lblInfo.setText("Rutina seleccionada: " + rutina.getNombre() + " (" + rutina.getEjercicios().size() + " ejercicios)");
    }
    
    private void eliminarRutina() {
        Rutina seleccionada = listaRutinas.getSelectedValue();
        if (seleccionada == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una rutina para eliminar", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(
            this, 
            "¿Está seguro de que desea eliminar la rutina '" + seleccionada.getNombre() + "'?", 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            if (rutinaDAO.eliminar(seleccionada.getId())) {
                JOptionPane.showMessageDialog(this, "Rutina eliminada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarRutinas();
                txtDetalleRutina.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar la rutina", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}