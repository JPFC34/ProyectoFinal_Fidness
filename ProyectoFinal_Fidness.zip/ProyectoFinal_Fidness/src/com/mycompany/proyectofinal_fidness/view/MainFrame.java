package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.model.Usuario;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class MainFrame extends JFrame {
    private Usuario usuario;
    private JMenuBar menuBar;
    private JMenu menuEjercicios;
    private JMenu menuRutinas;
    private JMenuItem menuItemVerEjercicios;
    private JMenuItem menuItemCrearRutina;
    private JMenuItem menuItemVerRutinas;
    private JPanel panelBienvenida;

    public MainFrame(Usuario usuario) {
        this.usuario = usuario;
        
        setTitle("Fidness - Sistema de Gestión");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }
    
    private void initComponents() {
        // Barra de menú
        menuBar = new JMenuBar();
        
        // Menú Ejercicios
        menuEjercicios = new JMenu("Ejercicios");
        menuItemVerEjercicios = new JMenuItem("Ver Ejercicios");
        menuItemVerEjercicios.addActionListener(e -> {
            EjercicioFrame ejercicioFrame = new EjercicioFrame(usuario);
            ejercicioFrame.setVisible(true);
        });
        menuEjercicios.add(menuItemVerEjercicios);
        
        menuBar.add(menuEjercicios);
        
        // Menú Rutinas
        menuRutinas = new JMenu("Rutinas");
        menuItemCrearRutina = new JMenuItem("Crear Rutina");
        menuItemCrearRutina.addActionListener(e -> {
            RutinaFrame rutinaFrame = new RutinaFrame(usuario);
            rutinaFrame.setVisible(true);
        });
        menuRutinas.add(menuItemCrearRutina);
        
        menuItemVerRutinas = new JMenuItem("Mis Rutinas");
        menuItemVerRutinas.addActionListener(e -> {
            VerRutinasFrame verRutinasFrame = new VerRutinasFrame(usuario);
            verRutinasFrame.setVisible(true);
        });
        menuRutinas.add(menuItemVerRutinas);
        
        menuBar.add(menuRutinas);
        
        setJMenuBar(menuBar);
        
        // Panel de bienvenida
        panelBienvenida = new JPanel();
        panelBienvenida.add(new JLabel("Bienvenido " + usuario.getUsername() + " (" + usuario.getTipo() + ")"));
        
        add(panelBienvenida, BorderLayout.CENTER);
    }
}