package com.mycompany.proyectofinal_fidness.view;

import com.mycompany.proyectofinal_fidness.dao.EjercicioDAO;
import com.mycompany.proyectofinal_fidness.dao.RutinaDAO;
import com.mycompany.proyectofinal_fidness.model.Ejercicio;
import com.mycompany.proyectofinal_fidness.model.Rutina;
import com.mycompany.proyectofinal_fidness.model.Usuario;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class RutinaFrame extends JFrame {
    private Usuario usuario;
    private EjercicioDAO ejercicioDAO;
    private RutinaDAO rutinaDAO;
    private JTextField txtNombreRutina;
    private JList<Ejercicio> listaEjerciciosDisponibles;
    private DefaultListModel<Ejercicio> modeloDisponibles;
    private JList<Ejercicio> listaEjerciciosSeleccionados;
    private DefaultListModel<Ejercicio> modeloSeleccionados;
    private JButton btnAgregar;
    private JButton btnQuitar;
    private JButton btnGuardar;
    private JLabel lblInfo;

    public RutinaFrame(Usuario usuario) {
        this.usuario = usuario;
        this.ejercicioDAO = new EjercicioDAO();
        this.rutinaDAO = new RutinaDAO();
        
        setTitle("Fidness - Crear Rutina");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
        cargarEjerciciosDisponibles();
    }
    
    private void initComponents() {
        // Panel superior para nombre de rutina
        JPanel panelNombre = new JPanel(new FlowLayout());
        panelNombre.add(new JLabel("Nombre de la rutina:"));
        txtNombreRutina = new JTextField(30);
        panelNombre.add(txtNombreRutina);
        
        // Panel central para listas de ejercicios
        JPanel panelListas = new JPanel(new GridLayout(1, 3, 10, 10));
        
        // Lista de ejercicios disponibles
        JPanel panelDisponibles = new JPanel(new BorderLayout());
        panelDisponibles.setBorder(new TitledBorder("EJERCICIOS DISPONIBLES"));
        
        modeloDisponibles = new DefaultListModel<>();
        listaEjerciciosDisponibles = new JList<>(modeloDisponibles);
        listaEjerciciosDisponibles.setCellRenderer(new EjercicioListCellRenderer());
        panelDisponibles.add(new JScrollPane(listaEjerciciosDisponibles), BorderLayout.CENTER);
        
        // Botones para agregar/quitar
        JPanel panelBotones = new JPanel(new GridLayout(2, 1, 5, 20));
        btnAgregar = new JButton("AGREGAR >");
        btnAgregar.addActionListener(e -> agregarEjercicio());
        btnQuitar = new JButton("< QUITAR");
        btnQuitar.addActionListener(e -> quitarEjercicio());
        panelBotones.add(btnAgregar);
        panelBotones.add(btnQuitar);
        
        // Lista de ejercicios seleccionados
        JPanel panelSeleccionados = new JPanel(new BorderLayout());
        panelSeleccionados.setBorder(new TitledBorder("MI RUTINA PERSONALIZADA"));
        
        modeloSeleccionados = new DefaultListModel<>();
        listaEjerciciosSeleccionados = new JList<>(modeloSeleccionados);
        listaEjerciciosSeleccionados.setCellRenderer(new EjercicioListCellRenderer());
        panelSeleccionados.add(new JScrollPane(listaEjerciciosSeleccionados), BorderLayout.CENTER);
        
        panelListas.add(panelDisponibles);
        panelListas.add(panelBotones);
        panelListas.add(panelSeleccionados);
        
        // Panel inferior para botones de acción
        JPanel panelInferior = new JPanel(new FlowLayout());
        btnGuardar = new JButton("GUARDAR RUTINA");
        btnGuardar.addActionListener(e -> guardarRutina());
        panelInferior.add(btnGuardar);
        
        // Panel de información
        lblInfo = new JLabel("Seleccione ejercicios para agregar a su rutina");
        panelInferior.add(lblInfo);
        
        add(panelNombre, BorderLayout.NORTH);
        add(panelListas, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);
    }
    
    private void cargarEjerciciosDisponibles() {
        modeloDisponibles.clear();
        List<Ejercicio> ejercicios = ejercicioDAO.obtenerTodos();
        
        for (Ejercicio ejercicio : ejercicios) {
            modeloDisponibles.addElement(ejercicio);
        }
    }
    
    private void agregarEjercicio() {
        Ejercicio seleccionado = listaEjerciciosDisponibles.getSelectedValue();
        if (seleccionado != null) {
            modeloSeleccionados.addElement(seleccionado);
            actualizarInfo();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un ejercicio de la lista izquierda", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void quitarEjercicio() {
        Ejercicio seleccionado = listaEjerciciosSeleccionados.getSelectedValue();
        if (seleccionado != null) {
            modeloSeleccionados.removeElement(seleccionado);
            actualizarInfo();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un ejercicio de la lista derecha", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void actualizarInfo() {
        int count = modeloSeleccionados.size();
        if (count == 0) {
            lblInfo.setText("Seleccione ejercicios para agregar a su rutina");
        } else {
            lblInfo.setText("Ha seleccionado " + count + " ejercicio" + (count != 1 ? "s" : "") + " para su rutina");
        }
    }
    
    private void guardarRutina() {
        String nombre = txtNombreRutina.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un nombre para la rutina", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (modeloSeleccionados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Agregue al menos un ejercicio a la rutina", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Rutina rutina = new Rutina();
        rutina.setIdUsuario(usuario.getId());
        rutina.setNombre(nombre);
        
        int idRutina = rutinaDAO.crear(rutina);
        
        if (idRutina != -1) {
            // Agregar ejercicios a la rutina
            for (int i = 0; i < modeloSeleccionados.size(); i++) {
                Ejercicio ejercicio = modeloSeleccionados.getElementAt(i);
                rutinaDAO.agregarEjercicioARutina(idRutina, ejercicio.getId());
            }
            
            JOptionPane.showMessageDialog(this, "Rutina guardada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar la rutina", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}