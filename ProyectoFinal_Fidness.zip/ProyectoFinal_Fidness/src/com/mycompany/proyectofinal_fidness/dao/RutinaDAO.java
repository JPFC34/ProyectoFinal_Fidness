package com.mycompany.proyectofinal_fidness.dao;

import com.mycompany.proyectofinal_fidness.model.Ejercicio;
import com.mycompany.proyectofinal_fidness.model.Rutina;
import com.mycompany.proyectofinal_fidness.util.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RutinaDAO {
    public int crear(Rutina rutina) {
        String sql = "INSERT INTO rutina (id_usuario, nombre) VALUES (?, ?)";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, rutina.getIdUsuario());
            pstmt.setString(2, rutina.getNombre());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return -1;
    }
    
    public boolean agregarEjercicioARutina(int idRutina, int idEjercicio) {
        String sql = "INSERT INTO rutina_ejercicio (id_rutina, id_ejercicio) VALUES (?, ?)";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idRutina);
            pstmt.setInt(2, idEjercicio);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Rutina> obtenerPorUsuario(int idUsuario) {
        List<Rutina> rutinas = new ArrayList<>();
        String sql = "SELECT * FROM rutina WHERE id_usuario = ?";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idUsuario);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Rutina rutina = new Rutina();
                    rutina.setId(rs.getInt("id"));
                    rutina.setIdUsuario(rs.getInt("id_usuario"));
                    rutina.setNombre(rs.getString("nombre"));
                    
                    rutina.setEjercicios(obtenerEjerciciosDeRutina(rutina.getId()));
                    rutinas.add(rutina);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return rutinas;
    }
    
    private List<Ejercicio> obtenerEjerciciosDeRutina(int idRutina) {
        List<Ejercicio> ejercicios = new ArrayList<>();
        String sql = "SELECT e.* FROM ejercicio e " +
                     "JOIN rutina_ejercicio re ON e.id = re.id_ejercicio " +
                     "WHERE re.id_rutina = ?";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idRutina);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Ejercicio ejercicio = new Ejercicio();
                    ejercicio.setId(rs.getInt("id"));
                    ejercicio.setNombre(rs.getString("nombre"));
                    ejercicio.setCategoria(rs.getString("categoria"));
                    ejercicio.setDescripcion(rs.getString("descripcion"));
                    ejercicio.setVideoUrl(rs.getString("video_url"));
                    ejercicios.add(ejercicio);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return ejercicios;
    }
    
    public boolean eliminar(int idRutina) {
        try (Connection conn = ConexionDB.getConnection()) {
            // Primero eliminar los ejercicios asociados
            String sqlDeleteRelacion = "DELETE FROM rutina_ejercicio WHERE id_rutina = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlDeleteRelacion)) {
                pstmt.setInt(1, idRutina);
                pstmt.executeUpdate();
            }
            
            // Luego eliminar la rutina
            String sqlDeleteRutina = "DELETE FROM rutina WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlDeleteRutina)) {
                pstmt.setInt(1, idRutina);
                return pstmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}