package com.mycompany.proyectofinal_fidness.dao;

import com.mycompany.proyectofinal_fidness.model.Usuario;
import com.mycompany.proyectofinal_fidness.util.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {
    public Usuario validarCredenciales(String username, String password) {
        String sql = "SELECT * FROM usuario WHERE username = ? AND password = ?";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                usuario.setTipo(rs.getString("tipo"));
                return usuario;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
}