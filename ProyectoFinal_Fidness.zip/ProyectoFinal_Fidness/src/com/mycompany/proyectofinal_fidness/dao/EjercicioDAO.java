package com.mycompany.proyectofinal_fidness.dao;

import com.mycompany.proyectofinal_fidness.model.Ejercicio;
import com.mycompany.proyectofinal_fidness.util.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EjercicioDAO {
    public List<Ejercicio> obtenerTodos() {
        List<Ejercicio> ejercicios = new ArrayList<>();
        String sql = "SELECT * FROM ejercicio";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Ejercicio ejercicio = new Ejercicio();
                ejercicio.setId(rs.getInt("id"));
                ejercicio.setNombre(rs.getString("nombre"));
                ejercicio.setCategoria(rs.getString("categoria"));
                ejercicio.setDescripcion(rs.getString("descripcion"));
                ejercicio.setVideoUrl(rs.getString("video_url"));
                ejercicios.add(ejercicio);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return ejercicios;
    }
    
    public List<Ejercicio> obtenerPorCategoria(String categoria) {
        List<Ejercicio> ejercicios = new ArrayList<>();
        String sql = "SELECT * FROM ejercicio WHERE categoria = ?";
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, categoria);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Ejercicio ejercicio = new Ejercicio();
                    ejercicio.setId(rs.getInt("id"));
                    ejercicio.setNombre(rs.getString("nombre"));
                    ejercicio.setCategoria(rs.getString("categoria"));
                    ejercicio.setDescripcion(rs.getString("descripcion"));
                    ejercicio.setVideoUrl(rs.getString("video_url"));
                    ejercicios.add(ejercicio);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return ejercicios;
    }
}