package com.mycompany.proyectofinal_fidness.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexionDB {
    private static final String URL = "jdbc:h2:~/fidness";
    private static final String USER = "sa";
    private static final String PASS = "";
    
    static {
        try {
            // Cargar el driver de H2
            Class.forName("org.h2.Driver");
            
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();
            
            // Crear tabla Usuario
            stmt.execute("CREATE TABLE IF NOT EXISTS usuario (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY, " +
                         "username VARCHAR(50) UNIQUE NOT NULL, " +
                         "password VARCHAR(100) NOT NULL, " +
                         "tipo VARCHAR(20) NOT NULL)");
            
            // Crear tabla Ejercicio
            stmt.execute("CREATE TABLE IF NOT EXISTS ejercicio (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY, " +
                         "nombre VARCHAR(100) NOT NULL, " +
                         "categoria VARCHAR(50) NOT NULL, " +
                         "descripcion TEXT, " +
                         "video_url VARCHAR(255))");
            
            // Crear tabla Rutina
            stmt.execute("CREATE TABLE IF NOT EXISTS rutina (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY, " +
                         "id_usuario INT NOT NULL, " +
                         "nombre VARCHAR(100) NOT NULL, " +
                         "FOREIGN KEY (id_usuario) REFERENCES usuario(id))");
            
            // Crear tabla de relación Rutina-Ejercicio
            stmt.execute("CREATE TABLE IF NOT EXISTS rutina_ejercicio (" +
                         "id_rutina INT NOT NULL, " +
                         "id_ejercicio INT NOT NULL, " +
                         "PRIMARY KEY (id_rutina, id_ejercicio), " +
                         "FOREIGN KEY (id_rutina) REFERENCES rutina(id), " +
                         "FOREIGN KEY (id_ejercicio) REFERENCES ejercicio(id))");
            
            // Insertar usuario admin por defecto
            try {
                stmt.execute("INSERT INTO usuario (username, password, tipo) SELECT 'admin', 'admin123', 'admin' WHERE NOT EXISTS (SELECT 1 FROM usuario WHERE username = 'admin')");
            } catch (SQLException e) {
                // Ignorar si el usuario ya existe
            }
            
            // Insertar algunos ejercicios de ejemplo
            try {
                stmt.execute("INSERT INTO ejercicio (nombre, categoria, descripcion, video_url) SELECT 'Sentadillas', 'Pierna', 'Párate con los pies separados al ancho de los hombros. Baja como si te sentaras en una silla, manteniendo la espalda recta. Vuelve a la posición inicial.', 'https://ejemplo.com/sentadillas.mp4' WHERE NOT EXISTS (SELECT 1 FROM ejercicio WHERE nombre = 'Sentadillas')");
            } catch (SQLException e) {
                // Ignorar si el ejercicio ya existe
            }
            
            try {
                stmt.execute("INSERT INTO ejercicio (nombre, categoria, descripcion, video_url) SELECT 'Press de banca', 'Brazo', 'Acuéstate en un banco con una barra en las manos. Baja la barra lentamente hasta el pecho y luego empújala hacia arriba hasta extender los brazos.', 'https://ejemplo.com/press.mp4' WHERE NOT EXISTS (SELECT 1 FROM ejercicio WHERE nombre = 'Press de banca')");
            } catch (SQLException e) {
                // Ignorar si el ejercicio ya existe
            }
            
            try {
                stmt.execute("INSERT INTO ejercicio (nombre, categoria, descripcion, video_url) SELECT 'Dominadas', 'Espalda', 'Agarra una barra con las manos separadas al ancho de los hombros. Tira de tu cuerpo hacia arriba hasta que la barbilla pase la barra. Baja lentamente.', 'https://ejemplo.com/dominadas.mp4' WHERE NOT EXISTS (SELECT 1 FROM ejercicio WHERE nombre = 'Dominadas')");
            } catch (SQLException e) {
                // Ignorar si el ejercicio ya existe
            }
            
            try {
                stmt.execute("INSERT INTO ejercicio (nombre, categoria, descripcion, video_url) SELECT 'Plancha abdominal', 'Abdomen', 'Acuéstate boca abajo. Apoya tus antebrazos y levanta el cuerpo formando una línea recta. Mantén la posición durante 30-60 segundos.', 'https://ejemplo.com/plancha.mp4' WHERE NOT EXISTS (SELECT 1 FROM ejercicio WHERE nombre = 'Plancha abdominal')");
            } catch (SQLException e) {
                // Ignorar si el ejercicio ya existe
            }
            
            try {
                stmt.execute("INSERT INTO ejercicio (nombre, categoria, descripcion, video_url) SELECT 'Correr en el lugar', 'Cardio', 'Corre en el lugar levantando las rodillas lo más alto posible. Mantén un ritmo constante durante 1-2 minutos.', 'https://ejemplo.com/correr.mp4' WHERE NOT EXISTS (SELECT 1 FROM ejercicio WHERE nombre = 'Correr en el lugar')");
            } catch (SQLException e) {
                // Ignorar si el ejercicio ya existe
            }
            
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}